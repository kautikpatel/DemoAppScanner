package com.bobekos.bobek.scanner.scanner


internal data class Size(val width: Int, val height: Int)